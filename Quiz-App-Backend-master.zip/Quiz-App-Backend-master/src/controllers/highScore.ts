// HighScore.find({ quizId: quizId })
//   .sort({ score: -1 })
//   .limit(5)
//   .populate("quizId")
//   .exec((err, highscores) => {
//     if (err) {
//       // handle error
//     }
//     console.log(highscores);
//   });